Lab 4: Referential Integrity

During Part 4 of the practical, I encountered Error 1451 when I attempted to delete the department named Library and Information Science. MySQL refused to delete the department because a student was still assigned to it. This happened because of referential integrity, which ensures that foreign key relationships remain valid in a database.

To solve the problem, I first updated the student's department to Software Engineering. After moving the student, I executed the DELETE statement again, and it worked successfully.

Another possible solution would be to configure the foreign key with ON DELETE CASCADE. This would automatically delete dependent student records when the department is deleted. However, this could result in losing important student records.