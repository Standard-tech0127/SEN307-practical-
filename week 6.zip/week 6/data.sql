SHOW DATABASES;
USE sen307_11539;
SELECT * FROM Department;
SELECT COUNT(*) FROM Course;
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE Enrolment;
TRUNCATE TABLE CourseAllocation;
TRUNCATE TABLE Student;
TRUNCATE TABLE Lecturer;
TRUNCATE TABLE Course;
TRUNCATE TABLE Department;
SET FOREIGN_KEY_CHECKS = 1;
INSERT INTO Department (dept_name) VALUES
('Software Engineering'),
('Computer Science'),
('Artificial Intelligence'),
('Data Science'),
('Cybersecurity');

INSERT INTO Course
(course_code, course_title, credit_units, description, dept_id)
VALUES

('SEN307', 'Database Systems', 3,
'Relational database design, SQL queries, normalization, transactions and indexing using MySQL.',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('SEN301', 'Software Architecture', 3,
'Architectural styles, design patterns, microservices and how to structure large software systems.',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('COS301', 'Operating Systems', 3,
'Processes, threads, CPU scheduling, memory management and file systems.',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('COS305', 'Computer Networks', 3,
'TCP/IP, routing, switching, LAN and WAN design and network protocols.',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('AIN301', 'Introduction to Artificial Intelligence', 3,
'Intelligent agents, search algorithms, knowledge representation and reasoning.',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('AIN305', 'Machine Learning', 3,
'Supervised and unsupervised learning, neural networks, deep learning and model evaluation.',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('AIN307', 'Natural Language Processing', 3,
'Text processing, word embeddings, language models, sentiment analysis and chatbots.',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('DTS301', 'Data Visualization and Analytics', 2,
'Exploratory data analysis, charts, dashboards and telling stories with data.',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('DTS305', 'Big Data Technologies', 3,
'Distributed storage and processing of very large datasets with Hadoop and Spark.',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('CYB301', 'Network Security', 3,
'Firewalls, cryptography, intrusion detection and protecting networks from attacks.',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity'));

SELECT d.dept_name, COUNT(c.course_id) AS courses
FROM Department d
LEFT JOIN Course c ON d.dept_id = c.dept_id
GROUP BY d.dept_name;

SELECT dept_id, dept_name FROM Department;

SELECT course_id, course_code FROM Course;

INSERT INTO Lecturer
(staff_no, full_name, email, dept_id)
VALUES

('VUA/ST/101', 'Dr Amaka Okafor',
'a.okafor@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('VUA/ST/102', 'Dr Musa Bello',
'm.bello@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('VUA/ST/103', 'Dr Chinedu Eze',
'c.eze@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('VUA/ST/104', 'Dr Fatima Ibrahim',
'f.ibrahim@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('VUA/ST/105', 'Dr David James',
'd.james@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('VUA/ST/106', 'Dr Grace Nwosu',
'g.nwosu@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('VUA/ST/107', 'Dr Peter Okoro',
'p.okoro@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('VUA/ST/108', 'Dr Esther Musa',
'e.musa@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('VUA/ST/109', 'Dr Samuel Ade',
's.ade@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity')),

('VUA/ST/110', 'Dr Mary Johnson',
'm.johnson@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity'));

SELECT * FROM Lecturer;

INSERT INTO Student
(matric_no, full_name, gender, date_of_birth, dept_id)
VALUES

('11539000', 'Obiekwe Nnaedozie Anthony', 'M', '2007-08-09', 1),

('20231235', 'Ada Obi', 'F', '2005-03-14', 1),
('20231236', 'John Musa', 'M', '2004-11-02', 2),
('20231237', 'Chinedu Eze', 'M', '2003-08-21', 1),
('20231238', 'Fatima Bello', 'F', '2006-01-15', 2),
('20231239', 'Grace Okafor', 'F', '2005-06-20', 3),
('20231240', 'David James', 'M', '2004-09-11', 3),
('20231241', 'Esther Nwosu', 'F', '2007-02-12', 4),
('20231242', 'Peter Okoro', 'M', '2003-12-05', 5),
('20231243', 'Samuel Ade', 'M', '2005-07-19', 1),
('20231244', 'Mary Johnson', 'F', '2006-04-23', 2),
('20231245', 'Daniel Obi', 'M', '2004-02-17', 3),
('20231246', 'Joy Ibrahim', 'F', '2005-10-08', 4),
('20231247', 'Michael Uche', 'M', '2003-05-25', 5),
('20231248', 'Blessing Eze', 'F', '2006-08-14', 1),
('20231249', 'Emmanuel Musa', 'M', '2004-03-09', 2),
('20231250', 'Victoria James', 'F', '2007-06-18', 3),
('20231251', 'Paul Nnamdi', 'M', '2005-09-27', 4),
('20231252', 'Ruth David', 'F', '2003-11-13', 5),
('20231253', 'Josephine Okoro', 'F', '2006-12-01', 1);

SELECT * FROM Student;

SELECT student_id, matric_no, full_name
FROM Student;

SELECT lecturer_id, full_name
FROM Lecturer;

INSERT INTO Enrolment (student_id, course_id)
VALUES
(1,1),
(1,2),
(1,3),
(2,1),
(2,2),
(2,3),
(3,1),
(3,2),
(4,1),
(4,3),
(5,1),
(5,4),
(6,1),
(6,5),
(7,1),
(7,6),
(8,1),
(8,7),
(9,2),
(9,3),
(10,2),
(10,4),
(11,2),
(11,5),
(12,2),
(12,6),
(13,3),
(13,4),
(14,3),
(14,5),
(15,3),
(15,6),
(16,4),
(16,7),
(17,4),
(17,8),
(18,5),
(18,9),
(3,7),
(4,8);

SELECT * FROM Enrolment;

INSERT INTO CourseAllocation (course_id, lecturer_id)
VALUES
(1,1),
(1,2),
(2,2),
(3,3),
(4,4),
(5,5),
(6,6),
(7,7),
(8,8),
(9,9),
(10,10);

SELECT * FROM CourseAllocation;

SELECT matric_no, full_name, dept_id
FROM Student
WHERE matric_no = '11539000';

UPDATE Student
SET dept_id = (
    SELECT dept_id
    FROM Department
    WHERE dept_name = 'Computer Science'
)
WHERE matric_no = '11539000';

SELECT matric_no, full_name, dept_id
FROM Student
WHERE matric_no = '11539000';

SET SQL_SAFE_UPDATES = 0;

SET SQL_SAFE_UPDATES = 1;

INSERT INTO Department (dept_name)
VALUES ('Library and Information Science');

INSERT INTO Student
(matric_no, full_name, dept_id)
VALUES
(
    '20239999',
    'Transfer Student',
    (SELECT dept_id
     FROM Department
     WHERE dept_name = 'Library and Information Science')
);

UPDATE Student
SET dept_id = (
    SELECT dept_id
    FROM Department
    WHERE dept_name = 'Software Engineering'
)
WHERE matric_no = '20239999';

SELECT * FROM Department;

SELECT 'Departments' AS tbl, COUNT(*) AS total
FROM Department

UNION ALL

SELECT 'Lecturers', COUNT(*)
FROM Lecturer

UNION ALL

SELECT 'Students', COUNT(*)
FROM Student

UNION ALL

SELECT 'Courses', COUNT(*)
FROM Course

UNION ALL

SELECT 'Enrolments', COUNT(*)
FROM Enrolment

UNION ALL

SELECT 'Allocations', COUNT(*)
FROM CourseAllocation;

DELETE FROM Department
WHERE dept_name = 'Library and Information Science';


